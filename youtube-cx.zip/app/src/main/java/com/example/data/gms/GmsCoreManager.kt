package com.example.data.gms

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import com.example.data.model.GmsCoreInfo

class GmsCoreManager(private val context: Context) {

    companion object {
        const val GMS_PACKAGE_NAME = "com.gmscx.services"
    }

    fun getGmsCoreInfo(): GmsCoreInfo {
        val isInstalled = checkGmsCoreInstalled()
        var version = "Not Installed"
        if (isInstalled) {
            try {
                val packageInfo = context.packageManager.getPackageInfo(GMS_PACKAGE_NAME, 0)
                version = packageInfo.versionName ?: "0.0.1-cx"
            } catch (e: Exception) {
                version = "Installed (com.gmscx.services)"
            }
        }

        return GmsCoreInfo(
            packageName = GMS_PACKAGE_NAME,
            isInstalled = isInstalled,
            versionName = version,
            isAccountConnected = isInstalled,
            accountEmail = if (isInstalled) "user@gmscx.services" else "No account synced"
        )
    }

    fun checkGmsCoreInstalled(): Boolean {
        return try {
            context.packageManager.getPackageInfo(GMS_PACKAGE_NAME, PackageManager.GET_ACTIVITIES)
            true
        } catch (e: PackageManager.NameNotFoundException) {
            false
        } catch (e: Exception) {
            false
        }
    }

    fun openGmsCoreSettings(): Boolean {
        return try {
            val intent = context.packageManager.getLaunchIntentForPackage(GMS_PACKAGE_NAME)
                ?: Intent().setPackage(GMS_PACKAGE_NAME)
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(intent)
            true
        } catch (e: Exception) {
            false
        }
    }
}
