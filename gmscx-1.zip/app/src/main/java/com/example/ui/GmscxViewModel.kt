package com.example.ui

import android.app.Application
import android.content.Context
import androidx.credentials.CredentialManager
import androidx.credentials.CustomCredential
import androidx.credentials.GetCredentialRequest
import androidx.credentials.exceptions.GetCredentialException
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.AccountDao
import com.example.data.AccountEntity
import com.example.data.AccountType
import com.example.data.AppDatabase
import com.example.data.oauth.OAuthConfig
import com.example.data.oauth.OAuthManager
import com.example.data.oauth.OAuthProviderSpec
import com.example.data.oauth.OAuthTokenResponse
import com.example.data.oauth.UserProfileResult
import com.example.data.services.GmsServiceManager
import com.google.android.libraries.identity.googleid.GetGoogleIdOption
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.GoogleAuthProvider
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

sealed class UiEvent {
    data class ShowToast(val message: String) : UiEvent()
    data class AccountAdded(val email: String, val type: AccountType) : UiEvent()
}

data class OAuthDialogState(
    val isOpen: Boolean = false,
    val providerSpec: OAuthProviderSpec = OAuthConfig.GOOGLE_SPEC,
    val authUrl: String = "",
    val customClientId: String = "",
    val customClientSecret: String = "",
    val isLoading: Boolean = false,
    val errorMessage: String? = null
)

class GmscxViewModel(application: Application) : AndroidViewModel(application) {
    private val database = AppDatabase.getDatabase(application)
    private val accountDao: AccountDao = database.accountDao()
    val oauthManager = OAuthManager()
    val gmsServiceManager = GmsServiceManager()

    val accountsState: StateFlow<List<AccountEntity>> = accountDao.getAllAccounts()
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    val serviceState = gmsServiceManager.serviceState

    private val _oauthDialogState = MutableStateFlow(OAuthDialogState())
    val oauthDialogState: StateFlow<OAuthDialogState> = _oauthDialogState.asStateFlow()

    private val _selectedAccount = MutableStateFlow<AccountEntity?>(null)
    val selectedAccount: StateFlow<AccountEntity?> = _selectedAccount.asStateFlow()

    private val _uiEvents = MutableSharedFlow<UiEvent>()
    val uiEvents: SharedFlow<UiEvent> = _uiEvents.asSharedFlow()

    fun performGoogleSignIn(context: Context) {
        viewModelScope.launch {
            try {
                val credentialManager = CredentialManager.create(context)
                val googleIdOption = GetGoogleIdOption.Builder()
                    .setFilterByAuthorizedAccounts(false)
                    .setServerClientId(OAuthConfig.GOOGLE_SPEC.defaultClientId)
                    .setAutoSelectEnabled(false)
                    .build()

                val request = GetCredentialRequest.Builder()
                    .addCredentialOption(googleIdOption)
                    .build()

                val result = credentialManager.getCredential(context, request)
                val credential = result.credential

                if (credential is CustomCredential && credential.type == GoogleIdTokenCredential.TYPE_GOOGLE_ID_TOKEN_CREDENTIAL) {
                    val googleIdTokenCredential = GoogleIdTokenCredential.createFrom(credential.data)
                    val idToken = googleIdTokenCredential.idToken
                    val email = googleIdTokenCredential.id
                    val displayName = googleIdTokenCredential.displayName ?: googleIdTokenCredential.givenName ?: email.substringBefore("@")
                    val avatarUrl = googleIdTokenCredential.profilePictureUri?.toString()

                    runCatching {
                        val auth = FirebaseAuth.getInstance()
                        val firebaseCred = GoogleAuthProvider.getCredential(idToken, null)
                        auth.signInWithCredential(firebaseCred)
                    }

                    val profile = UserProfileResult(
                        email = email,
                        displayName = displayName,
                        avatarUrl = avatarUrl,
                        rawResponseJson = "{\"id_token\": \"$idToken\"}"
                    )

                    val tokenResp = OAuthTokenResponse(
                        accessToken = idToken,
                        refreshToken = "google_refresh_" + oauthManager.generateRandomString(16),
                        expiresInSeconds = 3600,
                        tokenType = "Bearer",
                        scope = OAuthConfig.GOOGLE_SPEC.defaultScopes
                    )

                    saveAccountToDb(AccountType.GOOGLE, profile, tokenResp)
                    _uiEvents.emit(UiEvent.ShowToast("Успешный вход в Google: $email"))
                } else {
                    _uiEvents.emit(UiEvent.ShowToast("Не удалось получить Google ID Token"))
                }
            } catch (e: GetCredentialException) {
                if (e.type.contains("CANCELED", ignoreCase = true) || e.type.contains("Canceled", ignoreCase = true)) {
                    // Пользователь отменил вход
                } else {
                    _uiEvents.emit(UiEvent.ShowToast("Google Sign-In: ${e.localizedMessage ?: e.type}"))
                    openOAuthFlow(AccountType.GOOGLE)
                }
            } catch (e: Exception) {
                _uiEvents.emit(UiEvent.ShowToast("Ошибка авторизации: ${e.localizedMessage}"))
                openOAuthFlow(AccountType.GOOGLE)
            }
        }
    }

    fun openOAuthFlow(type: AccountType) {
        val spec = OAuthConfig.getSpecForType(type)
        val url = oauthManager.buildAuthUrl(spec)
        _oauthDialogState.value = OAuthDialogState(
            isOpen = true,
            providerSpec = spec,
            authUrl = url,
            customClientId = spec.defaultClientId
        )
    }

    fun closeOAuthDialog() {
        _oauthDialogState.value = OAuthDialogState(isOpen = false)
    }

    fun updateCustomClientId(clientId: String) {
        val current = _oauthDialogState.value
        val newUrl = oauthManager.buildAuthUrl(current.providerSpec, customClientId = clientId)
        _oauthDialogState.value = current.copy(
            customClientId = clientId,
            authUrl = newUrl
        )
    }

    fun updateCustomClientSecret(secret: String) {
        _oauthDialogState.value = _oauthDialogState.value.copy(customClientSecret = secret)
    }

    fun onOAuthCodeReceived(code: String) {
        val current = _oauthDialogState.value
        if (current.isLoading) return

        _oauthDialogState.value = current.copy(isLoading = true, errorMessage = null)

        viewModelScope.launch {
            val tokenResult = oauthManager.exchangeCodeForToken(
                spec = current.providerSpec,
                code = code,
                customClientId = current.customClientId,
                customClientSecret = current.customClientSecret
            )

            tokenResult.fold(
                onSuccess = { tokenResp ->
                    fetchProfileAndSaveAccount(current.providerSpec, tokenResp)
                },
                onFailure = { err ->
                    val errorMsg = "OAuth error: ${err.localizedMessage ?: err.message}"
                    _oauthDialogState.value = current.copy(isLoading = false, errorMessage = errorMsg)
                    _uiEvents.emit(UiEvent.ShowToast(errorMsg))
                }
            )
        }
    }

    fun onDirectAccessTokenReceived(accessToken: String) {
        val current = _oauthDialogState.value
        _oauthDialogState.value = current.copy(isLoading = true, errorMessage = null)

        viewModelScope.launch {
            val dummyTokenResp = OAuthTokenResponse(
                accessToken = accessToken,
                refreshToken = null,
                expiresInSeconds = 3600,
                tokenType = "Bearer",
                scope = current.providerSpec.defaultScopes
            )
            fetchProfileAndSaveAccount(current.providerSpec, dummyTokenResp)
        }
    }

    private suspend fun fetchProfileAndSaveAccount(
        spec: OAuthProviderSpec,
        tokenResp: OAuthTokenResponse
    ) {
        val profileResult = oauthManager.fetchUserProfile(
            spec = spec,
            accessToken = tokenResp.accessToken,
            idToken = tokenResp.idToken
        )

        profileResult.fold(
            onSuccess = { profile ->
                if (profile.email.isNotBlank()) {
                    saveAccountToDb(spec.providerType, profile, tokenResp)
                } else {
                    val errorMsg = "Failed to retrieve email for ${spec.title}"
                    _oauthDialogState.value = _oauthDialogState.value.copy(isLoading = false, errorMessage = errorMsg)
                    _uiEvents.emit(UiEvent.ShowToast(errorMsg))
                }
            },
            onFailure = { err ->
                val errorMsg = "Profile request failed: ${err.localizedMessage ?: err.message}"
                _oauthDialogState.value = _oauthDialogState.value.copy(isLoading = false, errorMessage = errorMsg)
                _uiEvents.emit(UiEvent.ShowToast(errorMsg))
            }
        )
    }

    private suspend fun saveAccountToDb(
        type: AccountType,
        profile: UserProfileResult,
        tokenResp: OAuthTokenResponse
    ) {
        val existing = accountDao.getAccountByEmailAndType(profile.email, type)
        val entity = AccountEntity(
            id = existing?.id ?: 0,
            accountType = type,
            accountEmail = profile.email,
            displayName = profile.displayName,
            avatarUrl = profile.avatarUrl ?: existing?.avatarUrl,
            accessToken = tokenResp.accessToken,
            refreshToken = tokenResp.refreshToken ?: existing?.refreshToken,
            tokenExpiresAt = System.currentTimeMillis() + (tokenResp.expiresInSeconds * 1000),
            scopes = tokenResp.scope ?: type.name,
            isSyncEnabled = true,
            createdTimestamp = existing?.createdTimestamp ?: System.currentTimeMillis()
        )

        val id = accountDao.insertAccount(entity)
        val updatedAccount = accountDao.getAccountByEmailAndType(profile.email, type)
        if (updatedAccount != null) {
            _selectedAccount.value = updatedAccount
        }

        _oauthDialogState.value = OAuthDialogState(isOpen = false)
        _uiEvents.emit(UiEvent.AccountAdded(profile.email, type))
        _uiEvents.emit(UiEvent.ShowToast("Signed in as ${profile.email}"))
    }

    fun selectAccount(account: AccountEntity?) {
        _selectedAccount.value = account
    }

    fun deleteAccount(account: AccountEntity) {
        viewModelScope.launch {
            accountDao.deleteAccount(account)
            if (_selectedAccount.value?.id == account.id) {
                _selectedAccount.value = null
            }
            _uiEvents.emit(UiEvent.ShowToast("Removed ${account.accountEmail}"))
        }
    }

    fun toggleAccountSync(account: AccountEntity, enabled: Boolean) {
        viewModelScope.launch {
            accountDao.setAccountSync(account.id, enabled)
        }
    }

    fun registerAppPush(packageName: String, appName: String) {
        gmsServiceManager.registerNewAppGcm(packageName, appName)
        viewModelScope.launch {
            _uiEvents.emit(UiEvent.ShowToast("Registered FCM token for $appName"))
        }
    }

    fun unregisterAppPush(packageName: String) {
        gmsServiceManager.unregisterAppGcm(packageName)
        viewModelScope.launch {
            _uiEvents.emit(UiEvent.ShowToast("Unregistered $packageName"))
        }
    }
}
